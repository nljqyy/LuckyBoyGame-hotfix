﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HttpServer
{
   public interface IServer
    {

        //void OnGet(HttpRequest);
        void OnPost();
        void OnDefault();
    }

    public interface ILogger
    {
        void Log(object message);
    }

}
