﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace HttpServer
{
   public class BaseHeader
    {
        public string Body { get; set; }
        public Encoding Encoding { get; set; }
        public string Content_Type { get; set; }
        public string Content_Length { get; set; }
        public string Content_Encoding { get; set; }
        public string ContentLanguage { get; set;}
        public Dictionary<string, string> Headers { get; set; }

        protected string GetHeaderByKey(Enum header)
        {
            string fileName = header.GetDescription();
            if (fileName == null) return null;
            string value=null;
            Headers.TryGetValue(fileName, out value);
            return value;
        }

        protected string GetHeaderByKey(string fieldName)
        {
            string value = null;
            Headers.TryGetValue(fieldName, out value);
            return value;
        }

        protected void SetHeaderByKey(string fieldName,string value)
        {
            if (string.IsNullOrEmpty(fieldName)) return;
            if (Headers.ContainsKey(fieldName))
                Headers[fieldName] = value;
            else
                Headers.Add(fieldName,value);

        }
    }


    public static class HeaderHelper
    {
        public static string GetDescription(this Enum value)
        {
            var valueType = value.GetType();
            var memberName = Enum.GetName(valueType, value);
            if (memberName == null) return null;
            FieldInfo fileinfo = valueType.GetField(memberName);
            var attribute= Attribute.GetCustomAttribute(fileinfo, typeof(DescriptionAttribute));
            if (attribute == null) return null;
            return (attribute as DescriptionAttribute).Description;
        }
    }
}
