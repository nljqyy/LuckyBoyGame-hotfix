﻿using System;
using System.Text;
using System.Collections.Generic;
using NUnit.Framework;

namespace HttpServerLib.UnitTest
{
    [TestFixture]
    public class HttpServiceTest
    {
        
        [Test]
        public void TestGet()
        {
            
        }

        [Test]
        public void TestPost()
        {

        }
    }
}
