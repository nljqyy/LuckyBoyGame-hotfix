﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HTTPServerLib;
using HttpServer;

namespace HTTPServerLib
{
    class Program
    {
        static void Main(string[] args)
        {
            ExampleServer server = new ExampleServer("192.168.15.162", 4050);
            server.SetRoot(@"D:\Res");
            server.Logger = new ConsoleLogger();
            server.Start();
        }
    }
}
